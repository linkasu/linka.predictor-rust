# Exact model rebuild

Use Rust 1.98.1 and corresponding source 4568465fcc436345eb56dc49b44555b251b9c733.
Build cargo build --locked --release -p predictor-cli --bin lp on Linux.
Run lp compile model.arpa model.lpk frequencies.tsv -
Expected SHA256: b3e736c8b42f6b75f39c26076d13ac99a65e6d10ef43b92de13ac288953b430a.
Data CC0-1.0, code GPL-3.0-or-later. No original corpus or evaluation data.
